## 🔗 Project Overview
This project builds a regression model to predict a student's future score (0-100) using past performance data. 

### 🔍 Problem Statement
"Predict a student's likely score in future quizzes/exams based on their activity, attempts, hints used, and time spent on questions."

### 🔗 Dataset
- **Source:** `skill_builder_dataset.csv`
- **Path:** `data/raw/skill_builder_dataset.csv`

### 🌐 Key Features Used
| Feature               | Description                       |
|----------------------|-----------------------------------|
| correct              | Whether the student got it right |
| attempt_count        | Number of attempts taken         |
| ms_first_response    | Time taken to answer (ms)        |
| hint_count           | Number of hints used             |
| overlap_time         | Overlap time in answering        |
| opportunity          | Number of prior practices        |
| skill_id             | Encoded Skill/Topic ID           |

---

## 🔄 Approach
### 1. 🧲 Preprocessing
- Missing values filled.
- Categorical columns encoded.
- Created a **synthetic score column** based on:

```python
score = (
    correct * 100
    - attempt_count * 1
    - hint_count * 1
    - (ms_first_response / 30000)
    - (overlap_time / 30000)
    - opportunity * 0.3
).clip(0, 100)
```

### 2. 🔧 Model Training
- Compared two models:
  - **Random Forest Regressor**(**Best performing**)
  - **Linear Regression** 

**Final Model:** Random Forest Regressor
- MSE: ~0.15
- R2: ~1.00

### 3. 🎨 Streamlit App
A simple app where you can enter student activity data and predict their likely score.

---

## 🔧 Project Structure
```
use_case_2/
├── data/
│   ├── raw/               # Original dataset
│   └── processed/         # Cleaned & transformed data
├── model/                  # Saved models (.pkl)
├── notebooks/
│   ├── eda.ipynb
│   ├── preprocessing.ipynb
│   └── model_training.ipynb
├── app/
│   └── app2.py             # Streamlit app
└── eda/                    # Plots, reports
```

---

## 🏆 Final Results
| Model                   | MSE   | R2 Score |
|-------------------------|--------|----------|
| Linear Regression       | 64.16  | 0.97     |
| Random Forest Regressor | 00.15  | 1.00     | 

---

## 💡 Key Takeaways
- Correct answers give high scores, but hints, attempts, and time penalize the result.

---
