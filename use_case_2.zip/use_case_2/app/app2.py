import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load the trained model
model = joblib.load('D:/FinalProject/use_case_2/model/score_predictor.pkl')

# App Title
st.title("🎯 Student Score Prediction App")
st.write("Predict a student's future score (0-100) using performance data.")

st.markdown("### 🔧 Enter Student Performance Data")

skill_id = st.number_input("Skill ID (Encoded)", min_value=0)
problem_id = st.number_input("Problem ID (Encoded)", min_value=0)
type_ = st.number_input("Question Type (Encoded)", min_value=0)
answer_type = st.number_input("Answer Type (Encoded)", min_value=0)
correct = st.selectbox("Correct Answer?", [0, 1])
attempt_count = st.slider("Attempt Count", 0, 20, 1)
ms_first_response = st.slider("Time to Answer (ms)", 0, 100000, 5000)
hint_count = st.slider("Hint Count", 0, 10, 0)
overlap_time = st.slider("Overlap Time", 0, 100000, 0)
opportunity = st.slider("Opportunity", 0, 20, 1)

# Predict Button
if st.button("Predict Score"):
    input_data = pd.DataFrame({
        'skill_id': [skill_id],
        'problem_id': [problem_id],
        'type': [type_],
        'answer_type': [answer_type],
        'correct': [correct],
        'attempt_count': [attempt_count],
        'ms_first_response': [ms_first_response],
        'hint_count': [hint_count],
        'overlap_time': [overlap_time],
        'opportunity': [opportunity]
    })

    # Make prediction
    predicted_score = model.predict(input_data)[0]

    # Show result
    st.success(f"✅ Predicted Student Score: **{predicted_score:.2f} / 100**")
