
# 📊 Student Learning Style Clustering

This project clusters students based on their activity data to identify their learning styles: **Fast Learners**, **Visual Learners**, or **Slow Learners**.

---

## ✅ Problem Statement

Identify learning patterns in students using activity logs from an online learning platform to help personalize their learning experience.

---

## 📂 Dataset Used

The dataset includes the following columns:

| Column Name         | Description                                      |
|---------------------|--------------------------------------------------|
| assistment_id        | Unique ID of the learning task                   |
| correct              | Whether the student answered correctly           |
| attempt_count        | Number of attempts before submitting an answer   |
| ms_first_response    | Time (ms) taken to give the first response       |
| hint_count           | Number of hints used                             |
| overlap_time         | Time spent overlapping with hints or retries     |
| template_id          | Template of the question                         |
| answer_id            | Selected answer ID                               |
| first_action         | First action type on the question                |
| bottom_hint          | If a bottom hint was used                        |
| opportunity          | Number of prior attempts on the same skill       |

---

## 🔍 Techniques Used

- **EDA & Preprocessing:** Cleaned data, selected numeric columns
- **Feature Scaling:** StandardScaler
- **Dimensionality Reduction:** PCA (2 components)
- **Clustering Algorithms:** MiniBatchKMeans (final model), DBSCAN (exploratory)
- **Model Saving:** Saved models and scalers with joblib
- **Visualizations:** Cluster plots using PCA-reduced data

---

## 🔧 Clustering Results

| Cluster | Learning Style |
|--------|----------------|
| 0      | Visual Learner |
| 1      | Slow Learner   |
| 2      | Fast Learner   |

➡️ Most students were clustered as **Visual Learners**, indicating common learning behavior.

---

## 🚀 Streamlit App

1. Navigate to the app directory:
   ```bash
   cd app
   ```
2. Run the app:
   ```bash
   streamlit run app.py
   ```
3. Enter student activity data to predict learning style.

---

## 📈 Results

- Best clustering with **3 clusters** using MiniBatchKMeans.
- Majority of students are **Visual Learners**.
- Models and PCA saved in `/model`, visualizations in `/reports`.

---

## 📂 Folder Structure

```
├── data/
│   ├── raw/                  # Raw dataset
│   ├── processed/            # Cleaned dataset
├── model/                     # Saved scaler, PCA, and clustering models
├── eda/                   # Cluster visualizations
├── app/
│   └── app.py                 # Streamlit app
├── notebooks/                  # EDA, Preprocessing, Clustering notebooks
```
---