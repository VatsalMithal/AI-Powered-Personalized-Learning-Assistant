import streamlit as st
import pandas as pd
import joblib

# ✅ Load Trained Models
scaler = joblib.load('D:/FinalProject/use_case_3/model/scaler.pkl')
pca = joblib.load('D:/FinalProject/use_case_3/model/pca.pkl')
kmeans_model = joblib.load('D:/FinalProject/use_case_3/model/kmeans_model.pkl')


# ✅ Feature Columns Used for Clustering
feature_columns = [
    'assistment_id', 'correct', 'attempt_count', 'ms_first_response',
    'hint_count', 'overlap_time', 'template_id', 'answer_id',
    'first_action', 'bottom_hint', 'opportunity'
]

# ✅ App Title
st.title("🎯 Student Learning Style Clustering App")
st.write("Predict a student's learning style (Fast, Visual, Slow Learner) using activity data.")

# ✅ User Input Form
st.header("🔧 Enter Student Activity Data")
user_input = {}

for col in feature_columns:
    user_input[col] = st.number_input(f"{col}", value=0.0)

# ✅ Predict Learning Style
if st.button("Predict Learning Style"):
    # Convert to DataFrame
    input_df = pd.DataFrame([user_input])

    # Preprocess input
    input_scaled = scaler.transform(input_df)
    input_pca = pca.transform(input_scaled)

    # Predict cluster
    cluster_label = kmeans_model.predict(input_pca)[0]

    # Map cluster to learning style
    cluster_map = {
        0: "Fast Learner",
        1: "Visual Learner",
        2: "Slow Learner"
    }
    learning_style = cluster_map.get(cluster_label, "Unknown")

    # Display result
    st.success(f"✅ Predicted Learning Style: **{learning_style}**")
