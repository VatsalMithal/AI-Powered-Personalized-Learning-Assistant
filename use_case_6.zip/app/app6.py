import streamlit as st
import numpy as np
import pandas as pd
from PIL import Image, ImageOps
from tensorflow.keras.models import load_model

# Load Trained Model
model = load_model('D:/FinalProject/use_case_6/model/cnn_model.h5')

st.title("🧠 Handwritten Digit Recognition")
st.write("Upload an image of a single handwritten digit (0-9)")

# Image Upload Section
uploaded_file = st.file_uploader("Upload a digit image (28x28 grayscale)", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert("L")  # Convert to grayscale
    st.image(image, caption='Uploaded Image', width=150)

    # Preprocess the image
    image = image.resize((28, 28))
    img_array = np.array(image).astype('float32') / 255.0
    img_array = img_array.reshape(1, 28, 28, 1)

    # Make Prediction
    prediction = model.predict(img_array)
    predicted_class = np.argmax(prediction)

    st.success(f"✅ Predicted Digit: **{predicted_class}**")
