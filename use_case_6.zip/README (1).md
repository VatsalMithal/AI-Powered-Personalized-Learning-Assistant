
# Handwritten Digit Recognition

This project is about recognizing handwritten digits from 0 to 9 using a Convolutional Neural Network (CNN). The project uses the MNIST dataset in CSV format and builds a Streamlit web app for testing.

## 📌 Problem Statement

Handwritten digit recognition is a common computer vision problem. The goal is to predict the correct digit given an image of a handwritten number.

## 📊 Dataset

- **Source:** [MNIST in CSV - Kaggle](https://www.kaggle.com/datasets/oddrationale/mnist-in-csv)
- Contains grayscale images of digits 0 to 9.
- Image size: 28 x 28 pixels
- CSV files:
  - `mnist_train.csv` (60,000 rows)
  - `mnist_test.csv` (10,000 rows)

## 🔨 Tools & Libraries Used

- Python
- TensorFlow/Keras
- Pandas, NumPy
- Matplotlib, Seaborn
- Scikit-learn
- Streamlit

## 🧑‍💻 Approach

1. Exploratory Data Analysis (EDA)
2. Preprocessing: normalization, reshaping
3. Building and training a CNN model
4. Model evaluation using accuracy and confusion matrix
5. Creating a Streamlit web app to upload a digit image and predict its class

## 🚀 How to Run

1. Install the required libraries (TensorFlow, Streamlit, etc.).
2. Go to the `app/` folder and run the Streamlit app:
   ```
   streamlit run streamlit_app.py
   ```
3. Upload a single digit image to test the model.

## 📂 Folder Structure

```
digit_recognition/
│
├── data/
│   ├── raw/           # Original CSV files
│   └── processed/     # Preprocessed data
│
├── notebooks/         # Jupyter notebooks
│
├── model/
│   └── cnn_model.h5   # Saved trained CNN model
│
├── app/
│   └── streamlit_app.py
│
├── reports/           
│
└── README.md
```

## ✅ Results

- Achieved ~99% accuracy on the test set.
- The model predicts digits correctly on most images.