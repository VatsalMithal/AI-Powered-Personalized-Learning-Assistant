## 📌 Problem Statement
Automatically classify a student's essay into a specific topic to better understand their interests and the context of their answers.

## 🎯 Objective
Build machine learning models to detect the essay topic from the written answer using NLP techniques.

## 🛠️ Dataset
- **Source:** ASAP 2.0 Dataset (Kaggle)
- **Key Columns:** `full_text`, `prompt_name`, `score`
- **Topics:**
  - Driverless cars
  - Facial action coding system
  - Exploring Venus
  - The Face on Mars
  - A Cowboy Who Rode the Waves
  - Does the electoral college work?
  - Car-free cities

## 🧑‍💻 Approach
1. Cleaned and preprocessed the essay text.
2. Trained three models:
   - Logistic Regression (TF-IDF)
   - Random Forest Classifier (TF-IDF)
   - LSTM Neural Network (tokenized input)
3. Compared model performance.
4. Built a Streamlit app for real-time topic prediction.

## 📈 Model Comparison

| Model                | Accuracy |
|----------------------|----------|
| Logistic Regression  | 99.87%   |
| Random Forest        | 99.77%   |
| LSTM                 | 97.35%   |

✔️ Final Model Chosen: **Logistic Regression** (best performance & fastest)

## 🔗 Streamlit Features
- Paste essay text
- Select a model (Logistic Regression, Random Forest, LSTM)
- Predict topic and display results

## 📂 Folder Structure
usecase_5_topic_detection/
├── README.md
├── data/
     ├── raw/ → Original dataset files 
     └── processed/ → Cleaned essay data
├── model/ → Saved models (.pkl, .h5)
├── notebooks/ → EDA, preprocessing, model training
├── eda/ → EDA plots & topic counts
├── app/ → Streamlit app