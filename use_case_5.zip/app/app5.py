import os
import streamlit as st
import pickle
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from tensorflow.keras.models import load_model

# Load saved models
with open('D:/FinalProject/use_case_5/model/logistic_regression_model.pkl', 'rb') as f:
        lr_model = pickle.load(f)

with open('D:/FinalProject/use_case_5/model/random_forest_model.pkl', 'rb') as f:
        rf_model = pickle.load(f)

with open('D:/FinalProject/use_case_5/model/tokenizer.pkl', 'rb') as f:
        tokenizer = pickle.load(f)

with open('D:/FinalProject/use_case_5/model/tfidf_vectorizer.pkl', 'rb') as f:
        tfidf = pickle.load(f)

with open('D:/FinalProject/use_case_5/model/label_encoder.pkl', 'rb') as f:
        label_classes = pickle.load(f)

lstm_model = load_model('D:/FinalProject/use_case_5/model/topic_detection_model.h5', compile=False)

# Define basic text cleaning
import re
import string

def clean_text(text):
    text = text.lower()
    text = re.sub(r'\n', ' ', text)
    text = re.sub(r'\d+', '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

# Streamlit App
st.title("🧾 Essay Topic Detection App")
st.write("Enter your essay text below. The app will predict the most likely essay topic.")

# Add model selection dropdown
model_choice = st.selectbox("🔧 Select Model for Prediction:", ["Logistic Regression", "Random Forest", "LSTM"])

# Input text box
user_input = st.text_area("✍️ Paste your essay here:", height=300)

if st.button("🔍 Predict Topic"):
    if user_input.strip() == "":
        st.warning("Please enter some essay text.")
    else:
        # Clean text
        cleaned_text = clean_text(user_input)

        if model_choice in ["Logistic Regression", "Random Forest"]:
            vectorized_input = tfidf.transform([cleaned_text])

            if model_choice == "Logistic Regression":
                prediction = lr_model.predict(vectorized_input)
            else:
                prediction = rf_model.predict(vectorized_input)

            predicted_topic = label_classes[prediction[0]]

        elif model_choice == "LSTM":
            # Tokenize and pad input
            sequence = tokenizer.texts_to_sequences([cleaned_text])
            from tensorflow.keras.preprocessing.sequence import pad_sequences
            padded = pad_sequences(sequence, maxlen=200)

            prediction = lstm_model.predict(padded)
            predicted_class = prediction.argmax(axis=1)[0]
            predicted_topic = label_classes[predicted_class]

        st.success(f"✅ Predicted Topic: **{predicted_topic}**")