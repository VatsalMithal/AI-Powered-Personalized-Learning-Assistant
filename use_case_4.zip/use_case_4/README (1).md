## ✅ Project Overview
This project predicts whether a student is **likely to drop out of an online learning platform** based on their engagement and activity data.  
It uses an **XGBoost Classifier** to analyze factors like participation in discussions, resource usage, and attendance.

## 🔍 Problem Statement
- Many students leave online learning platforms due to low engagement, lack of participation, or absenteeism.
- The goal is to **identify such students early** so that interventions can be made.

## 📂 Dataset
- **Dataset Used:** xAPI-Edu-Data (cleaned)
- **Features:**
  - `gender`: Student's gender
  - `Topic`: Subject they are enrolled in
  - `ParentAnsweringSurvey`: Did their parent answer a survey
  - `StudentAbsenceDays`: Attendance category
  - `raisedhands`: Times the student raised hands in class
  - `VisITedResources`: Number of learning resources visited
  - `AnnouncementsView`: Number of times announcements were viewed
  - `Discussion`: Forum participation count
- **Target:**
  - `dropout_flag`: `1` for likely dropout, `0` for not likely

## ⚙️ Machine Learning Model
- **Algorithm:** XGBoost Classifier
- **Training:**
  - Supports categorical features directly (no manual encoding)
  - Split dataset into train and test sets (80/20)
- **Performance Metrics:** Accuracy, Confusion Matrix, Classification Report
- **Feature Importance:** Visualized using a bar chart

## 🌐 Streamlit App
The app includes:
- **Home page**: Project overview
- **Prediction page**: Enter student data and predict dropout risk
- **About page**: Credits and project info

Run the app:
```
cd app
streamlit run streamlit_app.py
```

## 📁 Folder Structure
```
project_root/
├── app/                       
│   └── streamlit_app.py
├── model/                      
│   └── xgboost_dropout_model.pkl
├── data/                       # Dataset
│   └── raw --> dataset.csv
├── notebooks/                  # Training notebooks
│   ├── eda.ipynb
│   ├── model_training.ipynb
├── eda/                     #  Saved plots
└── README.md                    # This file
```