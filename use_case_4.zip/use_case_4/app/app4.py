import streamlit as st
import pandas as pd
import joblib

# 📥 Load the trained XGBoost model
model = joblib.load("D:/FinalProject/use_case_4/model/xgboost_dropout_model.pkl")

# 🎯 Title
st.title("🎓 Dropout Risk Prediction App")

# 🎯 Prediction Page
st.header("Predict Dropout Risk")

    # 👤 Collect user inputs
gender = st.selectbox("Gender", ["M", "F"])
topic = st.selectbox("Topic", ["Math", "Science", "English", "IT", "French", "Spanish", "Arabic",
                                   "History", "Geography", "Biology", "Chemistry", "Physics", "Religion", "Quran"])
parent_survey = st.selectbox("Parent Answered Survey", ["Yes", "No"])
absence_days = st.selectbox("Student Absence Days", ["Under-7", "Above-7"])
raisedhands = st.slider("Raised Hands (0-100)", 0, 100, step=1)
visited_resources = st.slider("Visited Resources (0-100)", 0, 100, step=1)
announcements = st.slider("Announcements View (0-100)", 0, 100, step=1)
discussion = st.slider("Discussion Participation (0-100)", 0, 100, step=1)

    # 👉 Prepare the input data as a DataFrame
input_data = pd.DataFrame({
        'gender': [gender],
        'Topic': [topic],
        'ParentAnsweringSurvey': [parent_survey],
        'StudentAbsenceDays': [absence_days],
        'raisedhands': [raisedhands],
        'VisITedResources': [visited_resources],
        'AnnouncementsView': [announcements],
        'Discussion': [discussion]
    })

    # ⚙️ Ensure categorical columns are the right type
cat_cols = ['gender', 'Topic', 'ParentAnsweringSurvey', 'StudentAbsenceDays']
for col in cat_cols:
    input_data[col] = input_data[col].astype('category')

    # 🔮 Make Prediction
prediction = model.predict(input_data)

    # 🟢 Output result
if prediction[0] == 1:
        st.error("⚠️ The student is **likely to DROP OUT.**")
else:
        st.success("✅ The student is **NOT likely to drop out.**")