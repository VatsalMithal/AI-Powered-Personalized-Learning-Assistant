
import streamlit as st
from transformers import pipeline
import os
import torch

# Set Hugging Face cache path to D drive
os.environ["TRANSFORMERS_CACHE"] = "D:/hf_cache"

# Title and description
st.set_page_config(page_title="AI-Powered Topic Summarizer")
st.title("📚 AI-Powered Topic Summarizer")
st.write("Paste any educational article or paragraph below and generate a simplified 5-line summary.")

# Model selection
model_options = {
    'T5-small': 't5-small',
    'T5-base': 't5-base',
    'DistilBART (CNN)': 'sshleifer/distilbart-cnn-12-6'
}
selected_model = st.selectbox("Select Summarizer Model:", list(model_options.keys()))

# User input text
input_text = st.text_area("Paste your text here:", height=250)

# Summarize Button
if st.button("Summarize"):
    if not input_text.strip():
        st.warning("⚠️ Please paste some text to summarize.")
    else:
        with st.spinner(f"Generating summary using {selected_model}..."):
            summarizer = pipeline("summarization", model=model_options[selected_model], framework="pt")
            try:
                trimmed_text = input_text[:1000]
                summary = summarizer(trimmed_text, max_length=50, min_length=25, do_sample=False)[0]['summary_text']
                st.success("✅ Summary generated successfully!")
                st.markdown(f"### 📝 Summary:\n{summary}")
            except Exception as e:
                st.error(f"❌ Error generating summary: {e}")
