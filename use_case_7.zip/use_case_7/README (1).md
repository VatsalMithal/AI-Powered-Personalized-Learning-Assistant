## ✅ Problem Statement
Students and teachers often need quick summaries of long educational articles, lessons, or transcripts. Manually summarizing such content is time-consuming.  
This project builds an AI-powered topic summarizer that generates simplified **5-line summaries** of educational text using pre-trained language models.

---

## 📂 Dataset Used
**Dataset:** TED Talks Transcripts (Kaggle)  
**Source:** https://www.kaggle.com/datasets/rounakbanik/ted-talks  
**Key Column:** `transcript` — contains the full TED talk speech text.

---

## 🔍 Exploratory Data Analysis (EDA)
- Total Records: ~2,500 TED Talks
- Transcript lengths ranged from 100 to 4,000+ words
- Word Cloud generated for most common terms
- Histograms of transcript word counts plotted

---

## 🔑 Models Tested (Summarization)
| Model Name            | Hugging Face Checkpoint              |
|-----------------------|--------------------------------------|
| T5-small              | `t5-small`                          |
| T5-base               | `t5-base`                           |
| DistilBART            | `sshleifer/distilbart-cnn-12-6`     |

---

## 📊 Model Evaluation (ROUGE Scores)

| Model        | Avg ROUGE-1 | Avg ROUGE-2 | Avg ROUGE-L |
|--------------|--------------|--------------|--------------|
| T5-small     | ~0.32        | ~0.28        | ~0.30        |
| T5-base      | ~0.24        | ~0.15        | ~0.21        |
| DistilBART   | ~0.39        | ~0.36        | ~0.39        |

> 🔍 **Observation:** DistilBART showed slightly better performance, but all models generated meaningful summaries without fine-tuning.

---

## ⚙️ Summarization Flow
1. User inputs raw text/article.
2. Selected pre-trained model summarizes the input (max 5 lines).
3. Output displayed on the Streamlit app.
4. Hugging Face Transformers library used for summarization.

---

## 🚀 How to Run the App

### ▶️ Install Libraries
```bash
pip install -r requirements.txt
```

### ▶️ Run Streamlit App
```bash
streamlit run app/streamlit_app.py
```

### ▶️ Access the App
Open the URL shown in the terminal (usually `http://localhost:8501`).

---

## 📂 Project Folder Structure
```
use_case_7_topic_summarizer/
├── data/
│   ├── raw/           # transcripts.csv
│   └── processed/     # Summaries & cleaned data
├── notebooks/
│   │── eda.ipynb
│   └── summarizer_training.ipynb
│   └── summarizer_evaluation.ipynb
├── app/
│   └── streamlit_app.py
├── reports/
│   └── rouge_scores.csv
└── README.md
```